tinyMCE.addI18n('en.groupdocs',{
	desc : 'This is just a template button'
});
